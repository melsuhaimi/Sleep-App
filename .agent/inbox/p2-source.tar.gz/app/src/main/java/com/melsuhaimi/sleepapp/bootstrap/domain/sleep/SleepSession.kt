package com.melsuhaimi.sleepapp.bootstrap.domain.sleep

data class SleepSession(
    val sessionId: String,
    val startedAtEpochMillis: Long,
    val endedAtEpochMillis: Long? = null,
    val status: SleepSessionStatus,
) {
    init {
        require(sessionId.isNotBlank()) { "sessionId must not be blank" }
        require(startedAtEpochMillis >= 0L) { "startedAtEpochMillis must be non-negative" }
        require(endedAtEpochMillis == null || endedAtEpochMillis >= startedAtEpochMillis) {
            "endedAtEpochMillis must not precede startedAtEpochMillis"
        }
    }

    val sessionWindowMinutes: Int?
        get() = endedAtEpochMillis?.let { endedAt ->
            ((endedAt - startedAtEpochMillis) / MILLIS_PER_MINUTE).toInt()
        }

    private companion object {
        const val MILLIS_PER_MINUTE = 60_000L
    }
}

enum class SleepSessionStatus {
    IDLE,
    ARMED,
    TRACKING,
    WAKE_PENDING,
    REVIEW_PENDING,
    FINALIZED,
    EXPEDITION_RESOLVED,
    ABORTED,
}

object SleepSessionStateMachine {
    fun beginManual(
        sessionId: String,
        startedAtEpochMillis: Long,
    ): SleepSession = SleepSession(
        sessionId = sessionId,
        startedAtEpochMillis = startedAtEpochMillis,
        status = SleepSessionStatus.TRACKING,
    )

    fun recordManualWake(
        session: SleepSession,
        wakeAtEpochMillis: Long,
    ): SleepSession {
        require(session.status == SleepSessionStatus.TRACKING) {
            "manual wake requires a TRACKING session"
        }
        require(wakeAtEpochMillis >= session.startedAtEpochMillis) {
            "wake anchor must not precede the start anchor"
        }
        return session.copy(
            endedAtEpochMillis = wakeAtEpochMillis,
            status = SleepSessionStatus.WAKE_PENDING,
        )
    }

    fun abort(
        session: SleepSession,
        abortedAtEpochMillis: Long,
    ): SleepSession {
        require(session.status == SleepSessionStatus.TRACKING) {
            "abort requires a TRACKING session"
        }
        require(abortedAtEpochMillis >= session.startedAtEpochMillis) {
            "abort anchor must not precede the start anchor"
        }
        return session.copy(
            endedAtEpochMillis = abortedAtEpochMillis,
            status = SleepSessionStatus.ABORTED,
        )
    }
}
