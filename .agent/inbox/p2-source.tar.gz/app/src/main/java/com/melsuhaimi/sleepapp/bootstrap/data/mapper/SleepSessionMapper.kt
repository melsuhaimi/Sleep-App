package com.melsuhaimi.sleepapp.bootstrap.data.mapper

import com.melsuhaimi.sleepapp.bootstrap.data.persistence.SleepSessionEntity
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSession
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionStatus

fun SleepSessionEntity.toDomain(): SleepSession = SleepSession(
    sessionId = sessionId,
    startedAtEpochMillis = startedAtEpochMillis,
    endedAtEpochMillis = endedAtEpochMillis,
    status = SleepSessionStatus.valueOf(status),
)

fun SleepSession.toEntity(): SleepSessionEntity = SleepSessionEntity(
    sessionId = sessionId,
    startedAtEpochMillis = startedAtEpochMillis,
    endedAtEpochMillis = endedAtEpochMillis,
    status = status.name,
)
