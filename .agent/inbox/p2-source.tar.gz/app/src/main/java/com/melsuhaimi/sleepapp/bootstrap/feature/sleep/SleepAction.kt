package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

sealed interface SleepAction {
    data class SaveTargetMinutes(val minutes: Int) : SleepAction
    data object BeginSleep : SleepAction
    data object Wake : SleepAction
    data object Abort : SleepAction
}
