package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

sealed interface SleepEvent {
    data object OpenJournal : SleepEvent
    data object ReturnToPlan : SleepEvent
}
