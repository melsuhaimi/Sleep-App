package com.melsuhaimi.sleepapp.bootstrap.feature.journal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class JournalViewModel @Inject constructor(
    sleepSessionRepository: SleepSessionRepository,
) : ViewModel() {
    val uiState = sleepSessionRepository.observeJournalSessions()
        .map { sessions ->
            if (sessions.isEmpty()) {
                JournalUiState.Empty
            } else {
                JournalUiState.Content(sessions)
            }
        }
        .catch {
            emit(JournalUiState.Error("Could not load sleep-session history."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = JournalUiState.Loading,
        )
}
