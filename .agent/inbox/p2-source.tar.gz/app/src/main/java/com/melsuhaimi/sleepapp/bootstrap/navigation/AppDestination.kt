package com.melsuhaimi.sleepapp.bootstrap.navigation

object AppDestination {
    const val SLEEP_MODE = "sleep_mode"
}
