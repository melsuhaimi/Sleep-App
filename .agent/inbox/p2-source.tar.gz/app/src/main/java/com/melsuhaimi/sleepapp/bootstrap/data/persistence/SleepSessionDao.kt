package com.melsuhaimi.sleepapp.bootstrap.data.persistence

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SleepSessionDao {
    @Query(
        """
        SELECT * FROM sleep_session
        WHERE status IN ('ARMED', 'TRACKING')
        ORDER BY started_at_epoch_millis DESC
        LIMIT 1
        """,
    )
    fun observeActiveSession(): Flow<SleepSessionEntity?>

    @Query(
        """
        SELECT * FROM sleep_session
        WHERE ended_at_epoch_millis IS NOT NULL
          AND status != 'ABORTED'
        ORDER BY started_at_epoch_millis DESC
        """,
    )
    fun observeJournalSessions(): Flow<List<SleepSessionEntity>>

    @Query(
        """
        SELECT * FROM sleep_session
        WHERE status IN ('ARMED', 'TRACKING')
        ORDER BY started_at_epoch_millis DESC
        LIMIT 1
        """,
    )
    suspend fun getActiveSession(): SleepSessionEntity?

    @Query("SELECT * FROM sleep_session WHERE session_id = :sessionId LIMIT 1")
    suspend fun getSession(sessionId: String): SleepSessionEntity?

    @Insert
    suspend fun insertSession(session: SleepSessionEntity)

    @Update
    suspend fun updateSession(session: SleepSessionEntity)
}
