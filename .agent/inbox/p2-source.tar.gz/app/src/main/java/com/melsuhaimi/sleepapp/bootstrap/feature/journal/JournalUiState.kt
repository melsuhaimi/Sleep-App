package com.melsuhaimi.sleepapp.bootstrap.feature.journal

import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSession

sealed interface JournalUiState {
    data object Loading : JournalUiState
    data object Empty : JournalUiState
    data class Content(val sessions: List<SleepSession>) : JournalUiState
    data class Error(val message: String) : JournalUiState
}
