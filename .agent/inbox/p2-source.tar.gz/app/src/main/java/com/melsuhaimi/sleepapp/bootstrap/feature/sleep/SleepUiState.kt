package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSession

data class SleepUiState(
    val isLoading: Boolean = true,
    val targetMinutes: Int = 0,
    val activeSession: SleepSession? = null,
    val errorMessage: String? = null,
)
