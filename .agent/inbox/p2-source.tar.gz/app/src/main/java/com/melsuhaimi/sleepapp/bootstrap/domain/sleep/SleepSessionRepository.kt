package com.melsuhaimi.sleepapp.bootstrap.domain.sleep

import kotlinx.coroutines.flow.Flow

interface SleepSessionRepository {
    fun observeActiveSession(): Flow<SleepSession?>

    fun observeJournalSessions(): Flow<List<SleepSession>>

    suspend fun beginManualSession(
        sessionId: String,
        startedAtEpochMillis: Long,
    )

    suspend fun recordManualWake(
        sessionId: String,
        wakeAtEpochMillis: Long,
    )

    suspend fun abortManualSession(
        sessionId: String,
        abortedAtEpochMillis: Long,
    )
}
