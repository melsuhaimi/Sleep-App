package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun SleepPlanScreen(
    state: SleepUiState,
    onAction: (SleepAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (state.isLoading) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("Loading sleep plan")
        }
        return
    }

    var targetText by rememberSaveable(state.targetMinutes) {
        mutableStateOf(state.targetMinutes.takeIf { it > 0 }?.toString().orEmpty())
    }
    val targetMinutes = targetText.toIntOrNull()?.takeIf { it > 0 }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Text(
            text = "Sleep plan",
            style = MaterialTheme.typography.headlineMedium,
        )
        Text(
            text = "Use manual start and wake anchors. The session window is recorded locally on this phone.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedTextField(
            value = targetText,
            onValueChange = { value ->
                if (value.all(Char::isDigit)) {
                    targetText = value
                }
            },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Sleep target in minutes") },
            supportingText = {
                Text("Saved in app settings and used as your plan target.")
            },
            isError = targetText.isNotEmpty() && targetMinutes == null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
        )

        Button(
            onClick = {
                targetMinutes?.let { minutes ->
                    onAction(SleepAction.SaveTargetMinutes(minutes))
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = targetMinutes != null && targetMinutes != state.targetMinutes,
        ) {
            Text("Save plan")
        }

        Spacer(Modifier.weight(1f))

        state.errorMessage?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }

        Button(
            onClick = { onAction(SleepAction.BeginSleep) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            enabled = state.activeSession == null,
        ) {
            Text("Begin sleep")
        }
    }
}
