package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class SleepSessionGateViewModel @Inject constructor(
    sleepSessionRepository: SleepSessionRepository,
) : ViewModel() {
    val activeSession = sleepSessionRepository.observeActiveSession()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null,
        )
}
