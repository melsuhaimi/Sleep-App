package com.melsuhaimi.sleepapp.bootstrap.data.repository

import androidx.room.withTransaction
import com.melsuhaimi.sleepapp.bootstrap.data.mapper.toDomain
import com.melsuhaimi.sleepapp.bootstrap.data.mapper.toEntity
import com.melsuhaimi.sleepapp.bootstrap.data.persistence.SleepDatabase
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSession
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionRepository
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionStateMachine
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RoomSleepSessionRepository @Inject constructor(
    private val database: SleepDatabase,
) : SleepSessionRepository {
    private val sleepSessionDao = database.sleepSessionDao()

    override fun observeActiveSession() = sleepSessionDao.observeActiveSession()
        .map { entity -> entity?.toDomain() }

    override fun observeJournalSessions(): Flow<List<SleepSession>> =
        sleepSessionDao.observeJournalSessions()
            .map { entities -> entities.map { entity -> entity.toDomain() } }

    override suspend fun beginManualSession(
        sessionId: String,
        startedAtEpochMillis: Long,
    ) {
        database.withTransaction {
            check(sleepSessionDao.getActiveSession() == null) {
                "an active sleep session already exists"
            }
            sleepSessionDao.insertSession(
                SleepSessionStateMachine.beginManual(
                    sessionId = sessionId,
                    startedAtEpochMillis = startedAtEpochMillis,
                ).toEntity(),
            )
        }
    }

    override suspend fun recordManualWake(
        sessionId: String,
        wakeAtEpochMillis: Long,
    ) {
        database.withTransaction {
            val current = requireNotNull(sleepSessionDao.getSession(sessionId)) {
                "sleep session does not exist"
            }.toDomain()
            sleepSessionDao.updateSession(
                SleepSessionStateMachine.recordManualWake(
                    session = current,
                    wakeAtEpochMillis = wakeAtEpochMillis,
                ).toEntity(),
            )
        }
    }

    override suspend fun abortManualSession(
        sessionId: String,
        abortedAtEpochMillis: Long,
    ) {
        database.withTransaction {
            val current = requireNotNull(sleepSessionDao.getSession(sessionId)) {
                "sleep session does not exist"
            }.toDomain()
            sleepSessionDao.updateSession(
                SleepSessionStateMachine.abort(
                    session = current,
                    abortedAtEpochMillis = abortedAtEpochMillis,
                ).toEntity(),
            )
        }
    }
}
