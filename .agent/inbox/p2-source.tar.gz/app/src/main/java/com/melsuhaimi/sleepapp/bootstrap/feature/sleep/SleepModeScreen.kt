package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun SleepModeScreen(
    state: SleepUiState,
    onAction: (SleepAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val session = state.activeSession

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (state.isLoading || session == null) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("Restoring sleep session")
            return@Column
        }

        val startedAt = remember(session.startedAtEpochMillis) {
            formatTime(session.startedAtEpochMillis)
        }

        Text(
            text = "Sleep mode",
            style = MaterialTheme.typography.headlineMedium,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Manual session active",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Started $startedAt",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (state.targetMinutes > 0) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Plan target: ${state.targetMinutes} minutes",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Spacer(Modifier.weight(1f))

        state.errorMessage?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.height(16.dp))
        }

        Button(
            onClick = { onAction(SleepAction.Wake) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        ) {
            Text("I'm awake")
        }
        Spacer(Modifier.height(8.dp))
        TextButton(
            onClick = { onAction(SleepAction.Abort) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
        ) {
            Text("End accidental start")
        }
    }
}

private fun formatTime(epochMillis: Long): String =
    DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)
        .format(Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()))
