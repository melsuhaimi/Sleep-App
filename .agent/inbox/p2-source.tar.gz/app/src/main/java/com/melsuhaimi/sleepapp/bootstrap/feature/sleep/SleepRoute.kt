package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SleepRoute(
    viewModel: SleepViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    SleepPlanScreen(
        state = state,
        onAction = viewModel::onAction,
    )
}

@Composable
fun SleepModeRoute(
    onWakeRecorded: () -> Unit,
    onAbort: () -> Unit,
    viewModel: SleepViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var leavingSession by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                SleepEvent.OpenJournal -> onWakeRecorded()
                SleepEvent.ReturnToPlan -> onAbort()
            }
        }
    }

    LaunchedEffect(state.isLoading, state.activeSession, leavingSession) {
        if (!state.isLoading && state.activeSession == null && !leavingSession) {
            onAbort()
        }
    }

    SleepModeScreen(
        state = state,
        onAction = { action ->
            if (action == SleepAction.Wake || action == SleepAction.Abort) {
                leavingSession = true
            }
            viewModel.onAction(action)
        },
    )
}
