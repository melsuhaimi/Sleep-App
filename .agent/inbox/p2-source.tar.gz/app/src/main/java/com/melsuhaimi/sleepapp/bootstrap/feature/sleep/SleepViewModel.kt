package com.melsuhaimi.sleepapp.bootstrap.feature.sleep

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melsuhaimi.sleepapp.bootstrap.data.settings.SettingsRepository
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@HiltViewModel
class SleepViewModel @Inject constructor(
    private val sleepSessionRepository: SleepSessionRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {
    private val errorMessage = MutableStateFlow<String?>(null)
    private val _events = Channel<SleepEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    val uiState = combine(
        settingsRepository.settings,
        sleepSessionRepository.observeActiveSession(),
        errorMessage,
    ) { settings, activeSession, error ->
        SleepUiState(
            isLoading = false,
            targetMinutes = settings.sleepTargetMinutes,
            activeSession = activeSession,
            errorMessage = error,
        )
    }
        .catch {
            emit(
                SleepUiState(
                    isLoading = false,
                    errorMessage = "Could not load the sleep session.",
                ),
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SleepUiState(),
        )

    fun onAction(action: SleepAction) {
        when (action) {
            is SleepAction.SaveTargetMinutes -> saveTargetMinutes(action.minutes)
            SleepAction.BeginSleep -> beginSleep()
            SleepAction.Wake -> recordWake()
            SleepAction.Abort -> abortSleep()
        }
    }

    private fun saveTargetMinutes(minutes: Int) {
        if (minutes <= 0) {
            errorMessage.update { "Sleep target must be at least one minute." }
            return
        }
        launchCommand("Could not save the sleep target.") {
            settingsRepository.setSleepTargetMinutes(minutes)
        }
    }

    private fun beginSleep() {
        if (uiState.value.activeSession != null) {
            return
        }
        launchCommand("Could not begin the sleep session.") {
            sleepSessionRepository.beginManualSession(
                sessionId = UUID.randomUUID().toString(),
                startedAtEpochMillis = System.currentTimeMillis(),
            )
        }
    }

    private fun recordWake() {
        val activeSession = uiState.value.activeSession
        if (activeSession == null) {
            errorMessage.update { "No active sleep session was found." }
            return
        }
        launchCommand("Could not record the wake anchor.") {
            sleepSessionRepository.recordManualWake(
                sessionId = activeSession.sessionId,
                wakeAtEpochMillis = System.currentTimeMillis(),
            )
            _events.send(SleepEvent.OpenJournal)
        }
    }

    private fun abortSleep() {
        val activeSession = uiState.value.activeSession
        if (activeSession == null) {
            viewModelScope.launch {
                _events.send(SleepEvent.ReturnToPlan)
            }
            return
        }
        launchCommand("Could not end the accidental session.") {
            sleepSessionRepository.abortManualSession(
                sessionId = activeSession.sessionId,
                abortedAtEpochMillis = System.currentTimeMillis(),
            )
            _events.send(SleepEvent.ReturnToPlan)
        }
    }

    private fun launchCommand(
        failureMessage: String,
        block: suspend () -> Unit,
    ) {
        errorMessage.update { null }
        viewModelScope.launch {
            runCatching { block() }
                .onFailure {
                    errorMessage.update { failureMessage }
                }
        }
    }
}
