package com.melsuhaimi.sleepapp.bootstrap.app

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.composable
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.currentBackStackEntryAsState
import com.melsuhaimi.sleepapp.bootstrap.feature.foundation.FoundationRoute
import com.melsuhaimi.sleepapp.bootstrap.feature.journal.JournalRoute
import com.melsuhaimi.sleepapp.bootstrap.feature.sleep.SleepModeRoute
import com.melsuhaimi.sleepapp.bootstrap.feature.sleep.SleepRoute
import com.melsuhaimi.sleepapp.bootstrap.feature.sleep.SleepSessionGateViewModel
import com.melsuhaimi.sleepapp.bootstrap.navigation.AppDestination
import com.melsuhaimi.sleepapp.bootstrap.navigation.AppNavigation
import com.melsuhaimi.sleepapp.bootstrap.navigation.AppRoute
import com.melsuhaimi.sleepapp.bootstrap.navigation.rememberNavigationState
import com.melsuhaimi.sleepapp.bootstrap.ui.components.SleepScaffold
import com.melsuhaimi.sleepapp.bootstrap.ui.theme.SleepTheme

@Composable
fun SleepApp(
    sleepSessionGateViewModel: SleepSessionGateViewModel = hiltViewModel(),
) {
    SleepTheme {
        val navigationState = rememberNavigationState()
        val activeSession by sleepSessionGateViewModel.activeSession.collectAsStateWithLifecycle()
        val backStackEntry by navigationState.navController.currentBackStackEntryAsState()
        val destinationRoute = backStackEntry?.destination?.route
        val currentRoute = when (destinationRoute) {
            AppDestination.SLEEP_MODE -> AppRoute.SLEEP
            else -> AppRoute.fromRouteId(destinationRoute) ?: AppRoute.WORLD
        }

        LaunchedEffect(activeSession?.sessionId, destinationRoute) {
            if (activeSession != null && destinationRoute != AppDestination.SLEEP_MODE) {
                navigationState.enterSleepMode()
            }
        }

        SleepScaffold(
            currentRoute = currentRoute,
            onRouteSelected = navigationState::navigateTo,
            showBottomBar = destinationRoute != AppDestination.SLEEP_MODE,
        ) { contentPadding ->
            AppNavigation(
                navigationState = navigationState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(contentPadding),
            ) {
                composable(AppRoute.WORLD.routeId) {
                    FoundationRoute(
                        route = AppRoute.WORLD,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                composable(AppRoute.SLEEP.routeId) {
                    SleepRoute()
                }
                composable(AppDestination.SLEEP_MODE) {
                    SleepModeRoute(
                        onWakeRecorded = navigationState::finishSleepToJournal,
                        onAbort = navigationState::returnToSleepPlan,
                    )
                }
                composable(AppRoute.JOURNAL.routeId) {
                    JournalRoute()
                }
                composable(AppRoute.MENU.routeId) {
                    FoundationRoute(
                        route = AppRoute.MENU,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}
