package com.melsuhaimi.sleepapp.bootstrap.feature.journal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.melsuhaimi.sleepapp.bootstrap.domain.sleep.SleepSession
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun JournalScreen(
    state: JournalUiState,
    modifier: Modifier = Modifier,
) {
    when (state) {
        JournalUiState.Loading -> CenteredMessage(
            modifier = modifier,
            loading = true,
            title = "Loading journal",
        )
        JournalUiState.Empty -> CenteredMessage(
            modifier = modifier,
            title = "No sleep sessions yet",
            message = "Begin a manual session from Sleep, then record your wake anchor to add the first journal entry.",
        )
        is JournalUiState.Error -> CenteredMessage(
            modifier = modifier,
            title = "Journal unavailable",
            message = state.message,
        )
        is JournalUiState.Content -> JournalContent(
            sessions = state.sessions,
            modifier = modifier,
        )
    }
}

@Composable
private fun JournalContent(
    sessions: List<SleepSession>,
    modifier: Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = 24.dp,
            vertical = 32.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Text(
                text = "Journal",
                style = MaterialTheme.typography.headlineMedium,
            )
        }
        item {
            Text(
                text = "Manual session windows recorded from your start and wake anchors.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        items(
            items = sessions,
            key = SleepSession::sessionId,
        ) { session ->
            SessionRow(session = session)
            HorizontalDivider()
        }
    }
}

@Composable
private fun SessionRow(session: SleepSession) {
    val startText = remember(session.startedAtEpochMillis) {
        formatDateTime(session.startedAtEpochMillis)
    }
    val endText = remember(session.endedAtEpochMillis) {
        session.endedAtEpochMillis?.let(::formatDateTime).orEmpty()
    }
    val windowMinutes = session.sessionWindowMinutes ?: 0

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = startText,
            style = MaterialTheme.typography.titleMedium,
        )
        Text(
            text = "Wake anchor: $endText",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = "Session window: ${formatDuration(windowMinutes)}",
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun CenteredMessage(
    modifier: Modifier,
    title: String,
    message: String? = null,
    loading: Boolean = false,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (loading) {
                CircularProgressIndicator()
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
            )
            message?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun formatDateTime(epochMillis: Long): String =
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
        .format(Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()))

private fun formatDuration(minutes: Int): String {
    val hours = minutes / 60
    val remainingMinutes = minutes % 60
    return when {
        hours > 0 && remainingMinutes > 0 -> "${hours}h ${remainingMinutes}m"
        hours > 0 -> "${hours}h"
        else -> "${remainingMinutes}m"
    }
}
