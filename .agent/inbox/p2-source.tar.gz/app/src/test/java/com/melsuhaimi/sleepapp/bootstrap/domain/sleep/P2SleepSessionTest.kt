package com.melsuhaimi.sleepapp.bootstrap.domain.sleep

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class P2SleepSessionTest {
    @Test
    fun manualBeginCreatesTrackingSessionFromStartAnchor() {
        val session = SleepSessionStateMachine.beginManual(
            sessionId = "session_1",
            startedAtEpochMillis = 1_000L,
        )

        assertEquals(SleepSessionStatus.TRACKING, session.status)
        assertEquals(1_000L, session.startedAtEpochMillis)
        assertNull(session.endedAtEpochMillis)
    }

    @Test
    fun manualWakeRecordsEndAnchorAndMovesToWakePending() {
        val session = SleepSessionStateMachine.beginManual(
            sessionId = "session_2",
            startedAtEpochMillis = 1_000L,
        )

        val ended = SleepSessionStateMachine.recordManualWake(
            session = session,
            wakeAtEpochMillis = 1_000L + (450L * 60_000L),
        )

        assertEquals(SleepSessionStatus.WAKE_PENDING, ended.status)
        assertEquals(450, ended.sessionWindowMinutes)
    }

    @Test
    fun accidentalSessionCanBeAborted() {
        val session = SleepSessionStateMachine.beginManual(
            sessionId = "session_3",
            startedAtEpochMillis = 5_000L,
        )

        val aborted = SleepSessionStateMachine.abort(
            session = session,
            abortedAtEpochMillis = 8_000L,
        )

        assertEquals(SleepSessionStatus.ABORTED, aborted.status)
        assertEquals(8_000L, aborted.endedAtEpochMillis)
    }

    @Test(expected = IllegalArgumentException::class)
    fun wakeBeforeStartIsRejected() {
        val session = SleepSessionStateMachine.beginManual(
            sessionId = "session_4",
            startedAtEpochMillis = 10_000L,
        )

        SleepSessionStateMachine.recordManualWake(
            session = session,
            wakeAtEpochMillis = 9_999L,
        )
    }

    @Test(expected = IllegalArgumentException::class)
    fun finalizedManualWakeCannotBeWokenAgain() {
        val session = SleepSessionStateMachine.recordManualWake(
            session = SleepSessionStateMachine.beginManual(
                sessionId = "session_5",
                startedAtEpochMillis = 10_000L,
            ),
            wakeAtEpochMillis = 20_000L,
        )

        SleepSessionStateMachine.recordManualWake(
            session = session,
            wakeAtEpochMillis = 30_000L,
        )
    }
}
